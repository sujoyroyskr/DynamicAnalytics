1. Change filename in my_data.m to be the data file that you'd like to use.
2. Run main_1sim.m to view predicted vs. measured values.
3. Run main_2opt.m to optimize the parameter values.